package br.unicesumar.escoladeti2015time04.usuario;

public enum Status {
    ATIVO, INATIVO;
}
